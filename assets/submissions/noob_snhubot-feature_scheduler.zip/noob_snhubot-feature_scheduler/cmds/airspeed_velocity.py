
command = "what is the airspeed velocity of an unladen swallow?"
public = True

def execute(command, user):
    attachment = None
    response = "https://youtu.be/y2R3FvS4xr4?t=14s"

    return response, attachment