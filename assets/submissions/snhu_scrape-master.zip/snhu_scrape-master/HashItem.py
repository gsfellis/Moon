class HashItem:
    def __init__(self, key, value):
        self.key = key
        self.value = value
